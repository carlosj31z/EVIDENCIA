-- =============================================================
--  FASC-205 · Evidencias visuales de Controles de Cambio
--  Ejecutar UNA vez en Supabase → SQL Editor → New query → Run
-- =============================================================

create extension if not exists pgcrypto;

-- Acciones de los controles de cambio (se cargan desde el Excel de pendientes)
create table if not exists public.cc_acciones (
  id                    uuid primary key default gen_random_uuid(),
  codigo_cc             text not null,
  num_accion            text not null,
  descripcion           text,
  responsable           text,
  area                  text,
  fecha                 date,
  status_acciones       text,
  status                text,
  comentario            text,
  fecha_evidencia_ssuit text,
  activo                boolean not null default true,   -- false si ya no figura en el último Excel importado
  -- Datos del formato FASC-205 (editables en la app)
  seccion               text,
  planta                smallint not null default 2,
  anexo                 text not null default '-',
  texto_accion          text,
  por_pagina            smallint,
  generado_at           timestamptz,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  unique (codigo_cc, num_accion)
);

-- Imágenes de evidencia (el archivo vive en Storage, bucket "evidencias")
create table if not exists public.cc_evidencias (
  id            uuid primary key default gen_random_uuid(),
  accion_id     uuid not null references public.cc_acciones(id) on delete cascade,
  storage_path  text not null,          -- imagen actual (editada o no)
  original_path text,                   -- imagen tal como se pegó, para "Restaurar original"
  orden         int  not null default 0,
  ancho         int,
  alto          int,
  mime          text,
  created_at    timestamptz not null default now()
);
create index if not exists cc_evidencias_accion_idx on public.cc_evidencias(accion_id);

-- RLS: acceso para la app (clave anon). Ver README → Seguridad.
alter table public.cc_acciones   enable row level security;
alter table public.cc_evidencias enable row level security;

drop policy if exists cc_acciones_all on public.cc_acciones;
create policy cc_acciones_all on public.cc_acciones
  for all to anon, authenticated using (true) with check (true);

drop policy if exists cc_evidencias_all on public.cc_evidencias;
create policy cc_evidencias_all on public.cc_evidencias
  for all to anon, authenticated using (true) with check (true);

-- Bucket privado para las imágenes
insert into storage.buckets (id, name, public)
values ('evidencias', 'evidencias', false)
on conflict (id) do nothing;

drop policy if exists evidencias_rw on storage.objects;
create policy evidencias_rw on storage.objects
  for all to anon, authenticated
  using (bucket_id = 'evidencias') with check (bucket_id = 'evidencias');

